export const HomeCtaFooter = () => import('../..\\components\\home\\ctaFooter.vue' /* webpackChunkName: "components/home-cta-footer" */).then(c => wrapFunctional(c.default || c))
export const HomeHeroBanner = () => import('../..\\components\\home\\heroBanner.vue' /* webpackChunkName: "components/home-hero-banner" */).then(c => wrapFunctional(c.default || c))
export const HomeKeyBenefit = () => import('../..\\components\\home\\keyBenefit.vue' /* webpackChunkName: "components/home-key-benefit" */).then(c => wrapFunctional(c.default || c))
export const HomeKeyFeatures = () => import('../..\\components\\home\\keyFeatures.vue' /* webpackChunkName: "components/home-key-features" */).then(c => wrapFunctional(c.default || c))
export const HomeSalesPoint = () => import('../..\\components\\home\\salesPoint.vue' /* webpackChunkName: "components/home-sales-point" */).then(c => wrapFunctional(c.default || c))
export const UniversalAppBar = () => import('../..\\components\\universal\\appBar.vue' /* webpackChunkName: "components/universal-app-bar" */).then(c => wrapFunctional(c.default || c))

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
